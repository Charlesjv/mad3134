<?php
echo"Hello locations";

//1.connect to your database


$dbhost = "localhost";
	$dbuser = "root";
	$dbpassword = "";
	$dbname = "store";

	$conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);

//2. grab all the locations

	$query = "SELECT * from locations";

	$results = mysqli_query($conn, $query);
	
	$stores = array();
	
	while( $item = mysqli_fetch_assoc($results) ) {
		array_push($stores,$item);
		
		
	}
	
	//3. return all the locations as JSON
	
	// tell the browser we are sending json_decode
	header("Content-Type:application/json");
	
	//converting our array into json dictionary
	$json = json_encode($stores);
	// deal with any errors during the conversion
	if($json == false)
	{
			$errorMessage = array("error"=>json_last_error_msg());
			$json = json_encode($json);
			http_response_code(500);
	
	
	}
	echo $json;
		
?>