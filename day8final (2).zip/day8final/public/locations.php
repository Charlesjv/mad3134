<?php
	// about us
	include("header.php");
?>

<h1> LOCATIONS </h1>
