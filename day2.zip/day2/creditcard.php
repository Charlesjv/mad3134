<h1> check credit card </h1>
<?php
$cc = "4288631468815465";

echo"your credit card no.".$cc."<br>";

if(strlen($cc) == 16){
	//0. reverse the cc number
	
	$total = 0;
	$reversed = strrev($cc);
	echo" Reversed".$reversed."<br>";
	for($i=0;$i<16;$i++){
		echo $reversed[$i]."<br>";
	
	//1. loop through the numbers in the cc
	//2. if postion = odd,
	//2a. multiply by 2
	
	
	
	//2b. if multiply > 9 then convert otherwise, do nothing
	
	
	if($i%2==1){
	$num = $reversed[$i]*2;	
	
	if($num>9){
		$num = $num-9;
	}
	
	}
	else{
		
		$total = $total+$num;	}
	echo"-- converted number".$num."<br>";
	}
	}
else{
	echo " your credit card is not 16 digits! <br>";

}
	// otherwise do nothing
      // 3 add to the total!
	  
	  
	  
	  
// 4. after looping, do total%10	  
	
	
	


?>