

<h1> Hello! </h1>
<h2> This is the next page! </h2>

<?php
		
	if($_SERVER["REQUEST_METHOD"] == "POST") {
		// post
		echo "You came with a POST!";
	}
	else if($_SERVER["REQUEST_METHOD"] == "GET"){
		// get
		echo "You came with a GET!";
	}
	  
	
	// how do i get the stuff 
	// that was sent in the form?
	
	echo"<br> What's in the GET? <br>";
	print_r($_GET);

	if($_SERVER["REQUEST_METHOD"] == "GET"){
		echo "The student is: " . $_GET["studentName"] . "<br>";
		echo "The id is: " . $_GET["id"] . "<br>";
	}
	
	echo "<br> What's in the POST? <br>";
	print_r($_POST);
	
	if($_SERVER["REQUEST_METHOD"] == "POST"){
		echo "The student is: " . $_POST["studentName"] . "<br>";
		echo "The id is: " . $_POST["id"] . "<br>";
	}

	
	
	
	
	
	
	
	
	
	
	
	
?>
