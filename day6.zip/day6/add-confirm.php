<?php
	//@TODO: Put your PHP logic here
print_r($_POST);
$dbhost = "localhost";		// address of your database
	$dbuser = "root";
	$dbpassword = "";			// on MAMP, this is "root"
	$dbname = "shoppingcart";
	
	$name = $_POST["product_name"];
	$desc = $_POST["description"];
	$price = $_POST["product_price"];
	// 2.  CONNECT TO THE DATABASE
	$conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);
$query = 'INSERT INTO product (product_name, description, product_price) ' .
'VALUES ("' .$name . '","' . $desc . '","' . $price . '")';
$results = mysqli_query($conn, $query);
if($results){
	echo"OKAY";
	
}
else{
	echo "BAD";
	
}
?>
<!DOCTYPE html5>
<html>
<head>
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.indigo-pink.min.css">
	<script defer src="https://code.getmdl.io/1.3.0/material.min.js"></script>
	<style type="text/css">
		.mdl-grid {
			max-width:1024px;
			margin-top:40px;
		}
		
		h1 {
			font-size:36px;
		}
		h2 {
			font-size:30px;
		}
	</style>

</head>
<body>

	<div class="mdl-grid">
	  <div class="mdl-cell mdl-cell--12-col">
		<p> Put some messages here? </p>
		
		<a href="show-products.php" class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored">
			< Go Back 
		</a>
	  </div>
	</div>
	
</body>
</html>