<?php

if($_SERVER["REQUEST_METHOD"]== "GET"){

}
// read words from a file


$file = file_get_contents("simplewords.txt", true);

$words = str_word_count($file,1);


// randomly pick words from a array?
print_r(array_rand($words,10));
$length = count($words);
$picked = [];
$choices = [];

for($i=0; $i<10; $i++){
	$x = rand(0, count($choices)-1);
	$password = $choices[$x];

	$randomNumber = rand(0, $length-1);
	
		if(in_array($randomNumber, $picked) == true){
			continue;
		}
		else
		{
			array_push($choices, $words[$randomNumber]);
		}
	
	echo $words[$randomNumber]."<br>";
}



?>


<html>
<head>
</head>

<body>
<form action="main.php" method="POST">
<label> Enter a word:</label>
<input name="guess" type="text">
<button name = "submit"> Go</button>
</form>
</html>
