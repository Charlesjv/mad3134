<?php
	include("header.php");
?>

    <!-- BACKPACKS and BAGS -->
    <section class="section">
      <div class="container">
        <h1 class="title">Backpacks & Bags</h1>
        <h2 class="subtitle">
          A selection of awesome backpacks for your everyday commute.
        </h2>
      </div>
    </section>

    <section class="section">
      <div class="container">
        <!-- put your products in here -->
		1.create the html for one product-box
		<div>
		<img src="images/burnt-toast-donut.jpg">
		<p> Lemon sparkle donut</p>
		<button class="button is-info is-outlined">Add to cart</button>
		</div>
		
		<?php
		while( $product = mysqli_fetch_assoc($results)){
			
		}
		?>
		
		
      </div>
    </section>
	<script type="text/javascript">
    </script>
  </body>
</html>