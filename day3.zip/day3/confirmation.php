




<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Hello Bulma!</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.min.css">
    <script defer src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
  </head>
  <body>
  <section class="section">
    <div class="container">
      <h1 class="title">
        Order Confirmation
      </h1>
      <a href="checkout.php" > Go Back </a>
	  <?php



//test for error conditions

/*if(strlen($_POST["cc"])!= 16{
	echo"ERROR!";
	
} */

$name = $_POST["firstName"];
$email = $_POST["email"];
$cc = $_POST["ccno"];

if(empty($name)|| empty($email) || empty($cc)){
	echo"<br>Name email cc field is blank<br>";
}
if(strlen($cc) != 16) {
	echo "ERROR";
}
// check if credit card passes authentication
if(ccIsValid($cc)== true){
	ccIsValid();
}
else{(ccIsValid($cc)== false)
	echo"Credit card is invalid";

}

function ccIsValid($cc){
		$reversed = strrev($cc);
		
		// 1. loop through the numbers in the cc
		$total = 0;
		
		for ($i=0; $i< 16; $i++) {
			// @debug: print out each character

			if ($i % 2 == 1) {
				// do multiply + convert
				$num = $reversed[$i] * 2;
				if ($num > 9) {
					//conversion
					$num = $num - 9;
				}
			}
			else {
				//do nothing
				$num = $reversed[$i];
			}
			
			
			// 3. add to the total!
			$total = $total + $num;
		
		} // end for loop
					
		// 4. after looping, do total % 10
		if ($total % 10 == 0) {
			
			return true;
		}
		else {
		
			return false;
		}
}
 
//1. check if fields are blank



//2. check if credit dard is valid
//2a, check if cc is 16 digits
//2b


// if all conditions PASS then show success message
echo"<h2> Hey".$name."!<br>";
echo"<h2> Thank you for your order!<br>";
echo"<h2>We have a sent you a copy of your receipt to ".$email;
?>
    </div>
  </section>
  </body>
</html>